<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=\, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <title>Peduli Diri</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body style="background-color: #0099dd;">

   <div class="container position-absolute top-50 start-50 translate-middle">
      <div class="row d-flex justify-content-center align-items-center h-100">
         <div class="card" style="width: 20rem; border-radius:5%;">
            <img src="img/Logo.png" alt="logo" class="card-img-top mx-auto" style="width: 50%;">
            <hr>
            <form action="/register/daftar" method="post">
               {{ csrf_field() }}
               <div class="card-body">
                  <h4 class="card-title text-center">Daftar</h4>
                  <br>
                  <input class="form-control" type="text" name="nik" placeholder="NIK" required>
                  <br>
                  <input class="form-control" type="text" name="nama_lengkap" placeholder="Nama Lengkap" required>
               </div>

               <div class="card-body mx-auto">
                  <button type="submit" class="btn btn-success ">Daftar</button>
               </div>
               <div class="mx-auto">
                  <p style="text-align: center;" class="mb-10">Sudah Punya Akun? <a
                        class="text-dark-50 fw-bold" href="/">Login</a>
                  </p>
               </div>
            </form>

         </div>
      </div>
   </div>


</body>

</html>
