@include('header')
<div class="container">
   <br>
   <br>
   <h3 id="catatanperjalanan">Catatan Perjalanan</h3>
   <div class="row align-item-center">
      <div class="col-auto">
         <a class="btn btn-success" href="/catatan/tambah" role="button">Tambah Data</a>
      </div>
      <div class="col-auto">
         <a class="btn btn-primary" href="/catatan" role="button">Print out</a>
      </div>
      <div class="col-auto">
         <form action="/catatan/cari" method="GET">
            <input class="bg-light" type="text" name="cari" placeholder="Cari Lokasi" value="{{ old('cari') }}">

            <button type="submit" value="CARI" class="btn btn-warning">Search</button>
         </form>
      </div>
   </div>
   <br>
   <br>
   <div class="table-responsive">
      <table id="tabel" class="table table-hover table-bordered border-grey">
         <thead>
            <tr class="table-primary">
               <th scope="col">Tanggal</th>
               <th scope="col">Waktu</th>
               <th scope="col">Lokasi</th>
               <th scope="col">Suhu Tubuh</th>
               <th scope="col">Keterangan</th>
               <th scope="col">Action</th>

            </tr>

         </thead>
         @foreach ($tb_catatan as $c)
            <tbody>


               <tr>
                  <th scope="row">{{ $c->tanggal }}</th>
                  <td>Jam {{ $c->waktu }} </td>
                  <td>{{ $c->lokasi }}</td>
                  <td>{{ $c->suhu_tubuh }}^C</td>
                  <td>{{ $c->keterangan }}</td>
                  <td>
                     <a href="/catatan/edit/{{ $c->id_catatan }}" class="btn btn-primary">Edit</a>
                     <a href="/catatan/hapus/{{ $c->id_catatan }}" class="btn btn-danger">Hapus</a>
                  </td>
               </tr>

            </tbody>
         @endforeach
      </table>


      <br />
      Halaman : {{ $tb_catatan->currentPage() }} <br />
      Jumlah Data : {{ $tb_catatan->total() }} <br />
      Data Per Halaman : {{ $tb_catatan->perPage() }} <br />

      <br>

      {{ $tb_catatan->links() }}

   </div>
</div>

@include('footer')
