<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=\, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <title>Peduli Diri</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

   <style type="text/css">
      .carousel-caption {
         top: 35%;
      }

      .pagination li {
         float: left;
         list-style-type: none;
         margin: 5px;

      }

   </style>

</head>

<body>

   <div class="container-xxl">
      <div class="row pt-2">
         <div class="col-2">
            <img src="../img/Logo2.png" class="img-fluid ">
         </div>
         <div class="col-6">

         </div>
         <div class="col-4">
            <a href="/home" class="btn btn-outline-primary  " style="padding: 2% 10% 2% 10%;">Home</a>
            <a href="/catatan" class="btn btn-outline-primary" style="padding: 2% 10% 2% 10%;">Catatan</a>
            <a href="/" class="btn btn-outline-primary" style="padding: 2% 10% 2% 10%;">Logout</a>
         </div>
      </div>

   </div>
   <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
         <div class="carousel-item active" data-bs-interval="10000">
            <img src="../img/carousel-image.png" class="d-block w-100" alt="image1">
            <div class="carousel-caption d-none d-md-block p2">

               <h3>Selamat Datang User Di Aplikasi Peduli Diri</h3>
               <h5>~Catat Riwayat Perjalanan Anda Bersama Peduli Diri~</h5>
            </div>
         </div>
         <div class="carousel-item" data-bs-interval="2000">
            <img src="../img/carousel-image.png" class="d-block w-100" alt="image2">
            <div class="carousel-caption d-none d-md-block p2">
               <h3>Selamat Datang User Di Aplikasi Peduli Diri</h3>
               <h5>~Tetaplah Memakai Masker Dimanapun Kamu Berada~</h5>
            </div>
         </div>
         <div class="carousel-item">
            <img src="../img/carousel-image.png" class="d-block w-100" alt="image3">
            <div class="carousel-caption d-none d-md-block p2">
               <h3>Selamat Datang User Di Aplikasi Peduli Diri</h3>
               <h5>~Tetap Lakukan Protokol Kesehatan~</h5>
            </div>
         </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval"
         data-bs-slide="prev">
         <span class="carousel-control-prev-icon" aria-hidden="true"></span>
         <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval"
         data-bs-slide="next">
         <span class="carousel-control-next-icon" aria-hidden="true"></span>
         <span class="visually-hidden">Next</span>
      </button>
   </div>
