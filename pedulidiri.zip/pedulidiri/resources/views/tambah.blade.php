<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=\, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <title>Peduli Diri</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body style="background-color: #0099dd;">

   <div class="container position-absolute top-50 start-50 translate-middle">
      <div class="row d-flex justify-content-center align-items-center h-100">
         <div class="card" style="width: 20rem; border-radius:5%;">

            <form action="/catatan/store" method="post">
               {{ csrf_field() }}
               <div class="card-body">
                  <h4 class="card-title text-center">Tambah</h4>
                  <br>
                  <input class="form-control" type="date" placeholder="Tanggal" name="tanggal" required>
                  <br>
                  <input class="form-control" type="time" placeholder="waktu" name="waktu" required>
                  <br>
                  <input class="form-control" type="text" placeholder="Lokasi" name="lokasi" required>
                  <br>
                  <input class="form-control" type="varchar" placeholder="Suhu Tubuh" name="suhu_tubuh" required>
                  <br>
                  <input class="form-control" type="text" placeholder="Keterangan" name="keterangan" required>
               </div>

               <div class="card-body mx-auto">
                  <button type="submit" value="Simpan Data" class="btn btn-success">Simpan Data</button>
               </div>
            </form>

         </div>
      </div>
   </div>


</body>

</html>
