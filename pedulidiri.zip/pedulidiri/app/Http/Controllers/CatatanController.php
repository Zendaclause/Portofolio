<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Kyslik\ColumnSortable\Sortable;

class CatatanController extends Controller
{

    public function index()
    {

        $catatan = DB::table('tb_catatan')->paginate(10);

        return view('catatan', ['tb_catatan' => $catatan]);
    }

    public function tambah()
    {
        return view('tambah');
    }

    public function store(Request $request)
    {

        DB::table('tb_catatan')->insert([
            'tanggal' => $request->tanggal,
            'waktu' => $request->waktu,
            'lokasi' => $request->lokasi,
            'suhu_tubuh' => $request->suhu_tubuh,
            'keterangan' => $request->keterangan
        ]);
        return redirect('/catatan#catatanperjalanan');
    }

    public function edit($id)
    {
        $catatan = DB::table('tb_catatan')->where('id_catatan', $id)->get();

        return view('edit', ['tb_catatan' => $catatan]);
    }

    public function update(Request $request)
    {
        DB::table('tb_catatan')->where('id_catatan', $request->id)->update([
            'tanggal' => $request->tanggal,
            'waktu' => $request->waktu,
            'lokasi' => $request->lokasi,
            'suhu_tubuh' => $request->suhu_tubuh,
            'keterangan' => $request->keterangan
        ]);
        return redirect('/catatan#catatanperjalanan');
    }

    public function hapus($id)
    {
        DB::table('tb_catatan')->where('id_catatan', $id)->delete();

        return redirect('/catatan#catatanperjalanan');
    }

    public function cari(Request $request)
    {
        // menangkap data pencarian
        $cari = $request->cari;

        // mengambil data dari table pegawai sesuai pencarian data
        $catatan = DB::table('tb_catatan')
            ->where('lokasi', 'like', "%" . $cari . "%")

            ->paginate();

        // mengirim data pegawai ke view index
        return view('catatan', ['tb_catatan' => $catatan]);
    }
}
