<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PenggunaController extends Controller
{
    public function index()
    {
        return view('register');
    }
    public function daftar(Request $request)
    {
        // insert data ke table pegawai
        DB::table('tb_pengguna')->insert([
            'nik' => $request->nik,
            'nama_lengkap' => $request->nama_lengkap

        ]);
        // alihkan halaman ke halaman pegawai
        return redirect('/');
    }
    public function proses(Request $request)
    {
        // $this->validate($request, [
        //     'nik' => 'required|numeric',
        //     'nama_lengkap' => 'required'
        // ]);
        // DB::table('tb_pengguna')->validate([
        //     'nik' => $request->nik,
        //     'nama_lengkap' => $request->nama_lengkap
        // ]);

        return view('home');
    }

    public function input()
    {
        return view('login');
    }
}
