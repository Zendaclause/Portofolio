<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class sorting extends Model
{
    use Sortable;

    protected $table = 'tb_catatan';

    protected $fillable = ['tanggal', 'waktu', 'lokasi', 'suhu_tubuh', 'keterangan'];

    public $sortable = [
        'tanggal',
        'lokasi',
    ];

    public function category()
    {
        return $this->belongsTo('catatan');
    }
}
