<?php

use App\Http\Controllers\CatatanController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PenggunaController;
use App\Http\Controllers\TitleController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', [LoginController::class, 'login'])->name('login');
// Route::post('actionlogin', [LoginController::class, 'actionlogin'])->name('actionlogin');

// Route::get('home', [HomeController::class, 'index'])->name('home')->middleware('auth');
// Route::get('actionlogout', [LoginController::class, 'actionlogout'])->name('actionlogout')->middleware('auth');



Route::get('/', [PenggunaController::class, 'input']);
// Route::post('/proses', [PenggunaController::class, 'proses']);
Route::get('/home', [TitleController::class, 'index']);
Route::get('/catatan', [CatatanController::class, 'index']);
Route::get('/register', function () {
    return view('register');
});
Route::get('catatan/tambah', [CatatanController::class, 'tambah']);
Route::post('catatan/store', [CatatanController::class, 'store']);
Route::get('catatan/edit/{id}', [CatatanController::class, 'edit']);
Route::post('catatan/update', [CatatanController::class, 'update']);
Route::get('catatan/hapus/{id}', [CatatanController::class, 'hapus']);
Route::get('catatan/cari', [CatatanController::class, 'cari']);
Route::get('register', [PenggunaController::class, 'index']);
Route::post('register/daftar', [PenggunaController::class, 'daftar']);
